﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _09_Conversão_em_Dollar
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Dinheiro em Reais: ");
            double dimDim = double.Parse(Console.ReadLine());
            Console.WriteLine($"Considerando que US$1 vale R$3,75.\nVocê teria R${dimDim * 3.75} na conversão.");

            Console.ReadKey();
        }
    }
}
