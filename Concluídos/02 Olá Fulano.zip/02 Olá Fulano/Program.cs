﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _02_Olá_Fulano
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Qual é o seu nome? ");
            String nome = Console.ReadLine();
            Console.WriteLine($"Olá {nome}, é um prazer te conhecer!");
            
            Console.ReadKey();
        }
    }
}
