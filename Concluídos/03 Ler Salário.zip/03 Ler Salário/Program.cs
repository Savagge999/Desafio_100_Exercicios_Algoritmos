﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _03_Ler_Salário
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Nome do Funcionário: ");
            string nome = Console.ReadLine();
            Console.Write("Salário: ");
            double salario = double.Parse(Console.ReadLine());
            Console.WriteLine($"O funcionário {nome} tem um salário de R${salario} em Junho.");

            Console.ReadKey();
        }
    }
}
