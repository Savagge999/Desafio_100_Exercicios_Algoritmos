﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _04_Soma
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Digite um valor: ");
            int valor1 = int.Parse(Console.ReadLine());
            Console.Write("Digite um valor: ");
            int valor2 = int.Parse(Console.ReadLine());

            Console.WriteLine($"A soma entre {valor1} e {valor2} é igual a {valor1 + valor2}.");

            Console.ReadKey();
        }
    }
}
