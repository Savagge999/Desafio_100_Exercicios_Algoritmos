﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _05_Nota_Média
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Nota 1: ");
            double nota1 = double.Parse(Console.ReadLine());
            Console.Write("Nota 2: ");
            double nota2 = double.Parse(Console.ReadLine());

            Console.WriteLine($"A média entre {nota1} e {nota2} é igual a {(nota1 + nota2) / 2}");

            Console.ReadKey();
        }
    }
}
