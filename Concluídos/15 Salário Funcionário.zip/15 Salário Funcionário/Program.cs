﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _15_Salário_Funcionário
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double MENSAL = 2400;
            double DIARIA = 200;
            double HORA = 25;

            Console.WriteLine("Período Trabalhado.");

            Console.Write("Meses: ");
            int mesTrabalhado = int.Parse(Console.ReadLine());
            Console.Write("Dias: ");
            int diaTrabalhado = int.Parse(Console.ReadLine());
            Console.Write("Horas: ");
            int horaTrabalhada = int.Parse(Console.ReadLine());

            Console.WriteLine();

            double mesParcial = (mesTrabalhado * MENSAL);
            double diaParcial = (diaTrabalhado * DIARIA);
            double horaParcial = (horaTrabalhada * HORA);

            double total = (mesParcial + diaParcial + horaParcial);

            Console.WriteLine($"Funcionário trabalhou por: {mesTrabalhado} Meses, {diaTrabalhado} Dias e {horaTrabalhada} Horas.\n");
            Console.WriteLine($"Mêses trabalhado {mesTrabalhado}. Valor do Mês trabalhado: {mesParcial}");
            Console.WriteLine($"Dias trabalhado {diaTrabalhado}. Valor do Dia trabalhado: {diaParcial}");
            Console.WriteLine($"Horas trabalhada {horaTrabalhada}. Valor da Hora trabalhada: {horaParcial}\n");
            Console.WriteLine($"Seu salário é de R${total}.");

            Console.ReadKey();
        }
    }
}
