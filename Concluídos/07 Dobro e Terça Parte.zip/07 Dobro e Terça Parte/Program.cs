﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _07_Dobro_e_Terça_Parte
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Digite um número: ");
            double numero = double.Parse(Console.ReadLine());

            Console.WriteLine($"O dobro de {numero} é {numero * 2}");
            Console.WriteLine($"A terça parte de {numero} é {numero / 3}");

            Console.ReadKey();
        }
    }
}
