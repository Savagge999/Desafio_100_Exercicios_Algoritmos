﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _12_5__de_Desconto
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Digite o Valor: ");
            double valorNormal = double.Parse(Console.ReadLine());

            double valorComDesconto = (valorNormal * 0.95);

            Console.WriteLine($"Valor total com 5% de desconto: {valorComDesconto}");

            Console.ReadKey();
        }
    }
}
