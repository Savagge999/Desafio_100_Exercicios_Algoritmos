﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _11_Valor_de_Delta
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Digite o valor de a: ");
            double A = double.Parse(Console.ReadLine());

            Console.Write("Digite o valor de b: ");
            double B = double.Parse(Console.ReadLine());

            Console.Write("Digite o valor de c: ");
            double C = double.Parse(Console.ReadLine());

            double delta = (B * B) - (4 * A * C);

            Console.WriteLine($"\nDelta = {delta}");

            if (delta < 0)
            {
                Console.WriteLine("A equação não possui raízes reais.");
            }
            else
            {
                double x1 = (-B + Math.Sqrt(delta)) / (2 * A);
                double x2 = (-B - Math.Sqrt(delta)) / (2 * A);

                Console.WriteLine($"x1 = {x1}");
                Console.WriteLine($"x2 = {x2}");

                Console.ReadKey();
            }
        }
    }
}
