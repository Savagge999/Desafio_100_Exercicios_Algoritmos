﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _10_Mts_Quadrados
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Altura: ");
            double altura = double.Parse(Console.ReadLine());
            Console.Write("Largura: ");
            double largura = double.Parse(Console.ReadLine());

            double area = (altura * largura);
            double tinta = (area / 2);

            Console.WriteLine($"Você possui {area} Metros quadrados de área total.");
            Console.WriteLine($"Considerando que 1Lt de tinta pinta 2 Metros quadrados.");
            Console.WriteLine($"Você gastaria {tinta} Litros no total.");

            Console.ReadLine();
        }
    }
}
