﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _08_Valores_Relativos
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Digite uma distância em metros: ");
            double M = double.Parse(Console.ReadLine());
            Console.WriteLine($"{M / 1000}Km");
            Console.WriteLine($"{M / 100}Hm");
            Console.WriteLine($"{M / 10}Dam");
            Console.WriteLine($"{M * 10}dm");
            Console.WriteLine($"{M * 100}cm");
            Console.WriteLine($"{M * 1000}mm");

            Console.ReadKey();
        }
    }
}
