﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _06_Antecessor_e_Sucessor
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Digite um número: ");
            int numero = int.Parse(Console.ReadLine());

            Console.WriteLine($"O antecessor de {numero} é {numero - 1}");
            Console.WriteLine($"O sucessor de {numero} é {numero + 1}");

            Console.ReadKey();
        }
    }
}
