﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _18_Idade_Votar
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Qual seu ano de nascimento: ");
            int anoNascimento = int.Parse(Console.ReadLine());

            int media = (2025 - anoNascimento);

            Console.WriteLine();

            if (media >= 16)
            {
                Console.WriteLine("Parabêns!");
                Console.WriteLine($"Você tem {media} anos e já pode votar");
            }
            else if (media < 16)
            {
                Console.WriteLine($"Você tem {media} anos e não pode votar");
            }

            Console.ReadKey();
        }
    }
}
