﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _17_Multa_Velocidade
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Qual a velocidade atual: ");
            int velocidade = int.Parse(Console.ReadLine());

            Console.WriteLine();

            if (velocidade > 80)
            {
                int multa = ((velocidade - 80) * 5);
                Console.WriteLine($"Valor da multa: R${multa}.");
            }
            else
            {
                Console.WriteLine("Velocidade atual permitida.\nParabêns!");
            }

            Console.ReadKey();
        }
    }
}
