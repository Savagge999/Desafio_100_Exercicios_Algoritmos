﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _13_15__Bonificação
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Salário do Funcionário: ");
            double salario = double.Parse(Console.ReadLine());

            double bonificacao = (salario * 1.15);

            Console.WriteLine($"Seu salário com a bonificação é: {bonificacao}");

            Console.ReadKey();
        }
    }
}
