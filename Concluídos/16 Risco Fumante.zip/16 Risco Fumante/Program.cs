﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _16_Risco_Fumante
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Estimativa de vida resuzida de um fumante.");
            Console.Write("Quantos cigarros você fuma por dia: ");
            int cigarrosPorDia = int.Parse(Console.ReadLine());
            Console.Write("Por quantos anos você ´fumou na vida: ");
            int anosFumante = int.Parse(Console.ReadLine());

            double cigarrosTotais = ((cigarrosPorDia * 365) * anosFumante);
            double minutosEmDias = (cigarrosTotais * 10);
            double diasPerdidos = (minutosEmDias / 1440);

            Console.WriteLine($"Dias de vida perdido: {diasPerdidos:F2} Dias.");

            Console.ReadKey();
        }
    }
}
