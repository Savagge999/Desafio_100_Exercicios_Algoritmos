﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _14_Locadora_De_Carros
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Valor da diária do veículo: R$90");
            Console.WriteLine("Valor por Km percorrido no veículo: R$0,20\n");

            Console.Write("Quantos Km o veículo percorreu: ");
            double kilometros = double.Parse(Console.ReadLine());
            Console.Write("Quantos dias de aluguel pelo veículo: ");
            int dias = int.Parse(Console.ReadLine());

            double kmValor = (kilometros * 0.02);
            int diasValor = (dias * 90);

            double valor = (kmValor + diasValor);

            Console.WriteLine($"Valor total a pagar: {valor}.");

            Console.ReadKey();
        }
    }
}
